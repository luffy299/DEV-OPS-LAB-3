# Lab 3: Monitoring, Logging & DevSecOps

**GitHub Repository:** https://github.com/luffy299/DEV-OPS-LAB-3

**Student Name:** Kabir  
**Roll No / Register No:** 2301730183  
**Email:** kabir000029@gmail.com  
**College:** K. R. Mangalam University  
**University:** K. R. Mangalam University  
**Academic Program:** B.Tech CSE AI/ML  
**Semester:** 7th  
**Section:** C
**Course Activity:** Lab 3: Monitoring, Logging & DevSecOps  
**Date:** November 04, 2026  

## Question 2: Provision Scalable Infrastructure (Terraform)
**Marks:** 5 Marks

### Overview
This package contains Terraform (Infrastructure as Code) configuration files to declaratively provision horizontally scalable containerized infrastructure using the Docker provider.

### Architecture & Key Components
- `terraform/main.tf`: Configures the `kreuzwerker/docker` provider, provisions a dedicated bridge network (`lab3-tf-network`), builds the application image from source, and spawns `count = var.replicas` application containers.
- `terraform/variables.tf`: Parameterizes `replicas` (validated between 1 and 5), `base_host_port` (default 8180), and `feature_greeting_v2`.
- `terraform/outputs.tf`: Dynamically exports the provisioned URLs (`http://localhost:8180`, `http://localhost:8181`).
- `evidence/02-terraform-plan.png`: Execution plan screenshot showing 4 resources to add.

### Commands Executed
```bash
# 1. Initialize provider plugins
terraform -chdir=terraform init

# 2. Plan scalable deployment (2 replicas)
terraform -chdir=terraform plan -var='replicas=2'

# 3. Apply infrastructure
terraform -chdir=terraform apply -var='replicas=2' -auto-approve

# 4. Scale to 3 replicas
terraform -chdir=terraform apply -var='replicas=3' -auto-approve
```

### Observations
- Terraform creates predictable port bindings (`base_host_port + count.index`), preventing port collision during horizontal scaling.
- Input validation ensures `replicas` cannot exceed host resource boundaries.
- Plan output confirms clean addition of 1 network, 1 image, and 2 container instances (`Plan: 4 to add, 0 to change, 0 to destroy`).