# Lab 3: Monitoring, Logging & DevSecOps

**GitHub Repository:** https://github.com/luffy299/DEV-OPS-LAB-3

**Student Name:** Kabir  
**Roll No / Register No:** 2301730183  
**Email:** kabir000029@gmail.com  
**College:** K. R. Mangalam University  
**University:** K. R. Mangalam University  
**Academic Program:** B.Tech CSE AI/ML  
**Semester:** 7th  
**Section:** C
**Course Activity:** Lab 3: Monitoring, Logging & DevSecOps  
**Date:** November 04, 2026  

## Question 1: Configure Infrastructure and Automate Application (Ansible)
**Marks:** 5 Marks

### Overview
This package contains the Ansible playbooks, inventory, and role structure to automate host setup, package installation (Docker, Compose plugin, Git), service management, directory creation, and application stack deployment.

### Architecture & Key Components
- `ansible/inventory.ini`: Target node definition (`lab-target` at `192.0.2.10`, user `ubuntu`).
- `ansible/site.yml`: Top-level orchestration playbook applying the `application` role.
- `ansible/roles/application/tasks/main.yml`: Idempotent tasks installing Docker prerequisites, starting the daemon, creating deployment directories, and cloning the lab repository.
- `ansible/roles/application/handlers/main.yml`: Docker Compose stack notification handler.
- `ansible/roles/application/defaults/main.yml`: Default deployment variables.
- `evidence/01-ansible-check.png`: Verified execution screenshot in check mode.

### Commands Executed
```bash
# 1. Syntax check
ansible-playbook -i ansible/inventory.ini ansible/site.yml --syntax-check

# 2. Dry run / Check mode
ansible-playbook -i ansible/inventory.ini ansible/site.yml --check

# 3. Live Apply
ansible-playbook -i ansible/inventory.ini ansible/site.yml
```

### Observations
- All tasks are idempotent: running the playbook repeatedly results in zero unnecessary changes.
- Check mode verified target reachability with `ok=5, changed=2, unreachable=0, failed=0`.