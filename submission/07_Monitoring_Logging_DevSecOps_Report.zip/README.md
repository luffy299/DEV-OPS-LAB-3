# Lab 3: Monitoring, Logging & DevSecOps

**GitHub Repository:** https://github.com/luffy299/DEV-OPS-LAB-3

**Student Name:** Kabir  
**Roll No / Register No:** 2301730183  
**Email:** kabir000029@gmail.com  
**College:** K. R. Mangalam University  
**University:** K. R. Mangalam University  
**Academic Program:** B.Tech CSE AI/ML  
**Semester:** 7th  
**Section:** C
**Course Activity:** Lab 3: Monitoring, Logging & DevSecOps  
**Date:** November 04, 2026  

## Question 7: Monitoring, Logging, and DevSecOps Comprehensive Report
**Marks:** 10 Marks

This package contains the complete laboratory documentation report for Lab 3 in PDF and Microsoft Word (.docx) formats, complete with system architecture, implementation details, command logs, execution evidence screenshots, and operational analysis.

### Files Included:
- `07_Monitoring_Logging_DevSecOps_Report.pdf`: 9-page formal laboratory report with embedded photographic evidence.
- `07_Monitoring_Logging_DevSecOps_Report.docx`: Editable Microsoft Word document format.
- `evidence/`: High-resolution screenshots of all 6 laboratory experiments.
- `report_sources/`: Python source scripts used to generate the report documents.